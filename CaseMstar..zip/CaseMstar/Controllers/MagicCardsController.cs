﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using CaseMstar;

namespace CaseMstar.Controllers
{
    public class MagicCardsController : Controller
    {
        public void teste()
        {

            var dbContext = new SqliteDbContext();
            dbContext.Database.EnsureCreated();

            dbContext.MagicCards.AddRange(new MagicCard[]{
                new MagicCard(){
                Descrição="Ur-Dragon 2",
                Fabricante="Magic the Gathering",
                Nome="Ur-Dragon",
                Nregistro= 01,
                Tipo="Monster Spell",
                Data=DateTime.Now.ToString(),
                Local="RJ",
                Quantidade=1
                },
                new MagicCard(){
                Descrição="Ur-Dragon 2",
                Fabricante="Magic the Gathering",
                Nome="Ur-Dragon",
                Nregistro= 01,
                Tipo="Monster Spell",
                Data=DateTime.Now.ToString(),
                Local="RJ",
                Quantidade=1
                }
            });
            dbContext.SaveChanges();
        }


        public IActionResult Index()
        {
            // teste();

            var dbContext = new SqliteDbContext();
            var MagicCards = dbContext.MagicCards.ToList();
            return View(MagicCards);
        }


        public IActionResult Details(int? id)
        {
            if (id == null)
            {
                return  RedirectToAction(nameof(Index));
            }

            var dbContext = new SqliteDbContext();

            var magicCard = dbContext.MagicCards
                .FirstOrDefault(m => m.Id == id);
            if (magicCard == null)
            {
                return  RedirectToAction(nameof(Index));
            }

            return View(magicCard);
        }

        public IActionResult Create()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create([Bind("Id,Nome,Nregistro,Fabricante,Tipo,Descrição,Quantidade,Data,Local")] MagicCard magicCard)
        {
            if (magicCard.Nome != null && magicCard.Fabricante != null && magicCard.Tipo != null && magicCard.Descrição != null && magicCard.Local != null)
            {
                try
                {
                    var data = Convert.ToDateTime(magicCard.Data);
                }
                catch
                {
                    return View(magicCard);
                }
                try
                {
                    var dbContext = new SqliteDbContext();

                    dbContext.Add(magicCard);
                    dbContext.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View(magicCard);
                }
            }
            return View(magicCard);
        }


        public IActionResult Edit(int? id)
        {

            var dbContext = new SqliteDbContext();

            if (id == null)
            {
                return RedirectToAction(nameof(Index));
            }

            var magicCard = dbContext.MagicCards.Find(id);
            if (magicCard == null)
            {
                return RedirectToAction(nameof(Index));
            }
            return View(magicCard);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("Id,Nome,Nregistro,Fabricante,Tipo,Descrição,Quantidade,Data,Local")] MagicCard magicCard)
        {
            if (magicCard.Nome != null && magicCard.Fabricante != null && magicCard.Tipo != null && magicCard.Descrição != null && magicCard.Local != null)
            {
                try
                {
                    var data = Convert.ToDateTime(magicCard.Data);
                }
                catch
                {
                    return View(magicCard);
                }

                var dbContext = new SqliteDbContext();

                if (id != magicCard.Id)
                {
                    return RedirectToAction(nameof(Index));
                }

                try
                {
                    dbContext.Update(magicCard);
                    dbContext.SaveChanges();
                    return RedirectToAction(nameof(Index));
                }
                catch
                {
                    return View(magicCard);
                }
            }
            return View(magicCard);
        }


        public IActionResult Delete(int? id)
        {

            var dbContext = new SqliteDbContext();

            if (id == null)
            {
                return  RedirectToAction(nameof(Index));
            }

            var magicCard = dbContext.MagicCards
                .FirstOrDefault(m => m.Id == id);
            if (magicCard == null)
            {
                return  RedirectToAction(nameof(Index));
            }

            return View(magicCard);
        }

    
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {

            var dbContext = new SqliteDbContext();

            var magicCard = dbContext.MagicCards.Find(id);
            dbContext.MagicCards.Remove(magicCard);
            dbContext.SaveChanges();
            return RedirectToAction(nameof(Index));
        }
    }
}