﻿
using CaseMstar.Controllers;
using Microsoft.EntityFrameworkCore;
using System.Reflection;

namespace CaseMstar
{
    public class SqliteDbContext : DbContext
    {
        public DbSet<MagicCard> MagicCards { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite( "FileName=SqliteDb1", option => {
                option.MigrationsAssembly(Assembly.GetExecutingAssembly().FullName);
            });
            base.OnConfiguring(optionsBuilder);
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<MagicCard>().ToTable("MagicCards");
            modelBuilder.Entity<MagicCard>(entity =>
            {
                entity.HasKey(x => x.Id);
            });
            base.OnModelCreating(modelBuilder);
        }
    }
}

