﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CaseMstar
{
    public class MagicCard
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public int Nregistro { get; set; }
        public string Fabricante { get; set; }
        public string Tipo { get; set; }
        public string Descrição { get; set; }
        public int Quantidade { get; set; }
        public string Data { get; set; }
        public string Local { get; set; }
    
    }
}
